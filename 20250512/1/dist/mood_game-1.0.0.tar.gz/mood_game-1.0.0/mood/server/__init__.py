"""Server package for the MOOD game."""
