"""Client package for the MOOD game."""
