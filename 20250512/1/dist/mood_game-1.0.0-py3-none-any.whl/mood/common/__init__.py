"""Common utilities and models for the MOOD game."""
